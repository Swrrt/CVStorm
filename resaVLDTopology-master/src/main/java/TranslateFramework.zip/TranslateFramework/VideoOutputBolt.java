package TranslateFramework;

import backtype.storm.topology.base.BaseRichBolt;

/**
 * Created by swrrt on 6/10/2015.
 */
public class VideoOutputBolt {

}
